# for python 2.0 compatibility
from __future__ import absolute_import as _ai

# Version setup.
from ._version import __version__

__all__ = ['test']
from .core import *
